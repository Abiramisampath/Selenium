package hooks;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class PreLoginHooks extends TestNgHooks {

	@BeforeMethod
	public void beforeMethod() {
		super.beforeMethod();
		loginPage.doLogin(env.getProperty("username"), env.getProperty("password"));
	}

}
